#!/usr/bin/env python3
me='#!/usr/bin/env python3\nme=%r\nprint(me %% me)'
print(me % me)
