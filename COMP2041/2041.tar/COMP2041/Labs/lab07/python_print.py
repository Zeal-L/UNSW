#!/usr/bin/env python3

import sys

print("#!/usr/bin/env python3")
print(f'print({repr(sys.argv[1])})')
